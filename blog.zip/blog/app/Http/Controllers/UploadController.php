<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function index(){
        return view('image');
    }
    public function store(Request $request){
        $request->validate([
            'image'=>'required|image|mimes:jpeg,jpg,png,gif',
        ]);
        $imageName = time().'.'.$request->image->extension();

        $request->image->move(public_path('images'), $imageName);
        return back()
        ->withSuccess('You have successfully uploaded the image')
        ->withImageName( $imageName );
    }
}
